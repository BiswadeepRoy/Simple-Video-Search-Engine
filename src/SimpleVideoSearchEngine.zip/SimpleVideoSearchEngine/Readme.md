## Welcome to Simple Search Engine created using css,vanilla js and html

# Steps to Launch:
1. UnZip the files.
2. Just copy and paste the full path of the SimpleVideoSearchEngine\simpleVideoSearchEngine.js file in your browser url.
3. Click Enter and enjoy the videos.